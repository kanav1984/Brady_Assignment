package com.bradytechnologies.assignments.java.ejb.stateless.service;

import javax.ejb.Remote;

@Remote
public interface PetDetailsServiceRemote {
	
	public String[] getPetDetails();
	 

}
