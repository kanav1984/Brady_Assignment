package com.bradytechnologies.assignments.java.ejb.stateless.service;

import javax.ejb.LocalBean;
import javax.ejb.Schedule;
import javax.ejb.Stateless;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;

/**
 * Session Bean implementation class PetDetailsCheckerTimerService
 */
@Stateless
@LocalBean
public class PetDetailsCheckerTimerService {

    public PetDetailsCheckerTimerService() 
    {
    }
	
    @Schedule(second="*/30", minute="*", hour="*/1")
	public void checkVaccinationTime()
	{
		System.out.println("Kanav - checkVaccinationTime() method called in Timer EJB - PetDetailsCheckerTimerService");
		System.out.println("Sending message to queue from PetDetailsCheckerTimerService class");
		sendMessageToQueue();
		System.out.println("Kanav - Message SENT and checkVaccinationTime() is COMPLETE PetDetailsCheckerTimerService class");
	}
    
    private void sendMessageToQueue()
    {
    	Connection jmsConn = null;
    	Session jmsSession = null;

    	try {

    		Context initCtx = new InitialContext(System.getProperties());
    		Queue petServiceQueue = (javax.jms.Queue) initCtx.lookup("java:/jms/queue/PetServiceQueue");

    		// Perform the JNDI lookups
    		String jndiFactoryStr = "java:/ConnectionFactory";
    		System.out.println("Looking factory with jndi in JSP is " + jndiFactoryStr);

    		ConnectionFactory connectionFactory = (ConnectionFactory) initCtx.lookup(jndiFactoryStr);
    		System.out.println("Kanav connfactory from JSP  is " + connectionFactory);
    		jmsConn = connectionFactory.createConnection();
    		jmsSession = jmsConn.createSession(false, Session.AUTO_ACKNOWLEDGE);

    		MessageProducer sender = jmsSession.createProducer(petServiceQueue);
    		TextMessage message = jmsSession.createTextMessage();
    		System.out.println("Kanav - Before sending message to Queue");
    		message.setText("Kanav This is Message for Queue from Timer-EJB");
    		sender.send(message);
    		System.out.println("Message has been sent to Queue from Timer-EJB");
    		jmsSession.close();
    		jmsConn.close();
    	}
    	catch (Exception ex) 
    	{
    		ex.getMessage();
    		ex.printStackTrace();
    		System.out.println("Exceotion occured");
    	}
    	finally
    	{
    		try
    		{
    			jmsSession.close();
    			jmsConn.close();
    		}
    		catch(Exception ex)
    		{
    			System.out.println("Exception Occured while closing session and connection");
    			ex.getMessage();
    			ex.printStackTrace();
    		}
    	}
    	
    }

}
