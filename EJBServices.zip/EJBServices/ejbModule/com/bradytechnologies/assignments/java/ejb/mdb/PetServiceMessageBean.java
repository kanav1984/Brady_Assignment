package com.bradytechnologies.assignments.java.ejb.mdb;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

/**
 * Message-Driven Bean implementation class for: PetServiceMessageBean
 */
@MessageDriven(
		activationConfig = { @ActivationConfigProperty(
				propertyName = "destination", propertyValue = "java:/jms/queue/PetServiceQueue"), @ActivationConfigProperty(
				propertyName = "destinationType", propertyValue = "javax.jms.Queue")
		}, 
		mappedName = "java:/jms/queue/PetServiceQueue")
public class PetServiceMessageBean implements MessageListener {

    public PetServiceMessageBean() 
    {
    	
    }
	
    public void onMessage(Message message) 
    {
    	try {
			System.out.println("Kanav - Inside PetServiceMDB onMessage() method before printing message of queue");
			System.out.println(message);
			System.out.println(message.toString());
			System.out.println("Kanav - Inside PetServiceMDB onMessage() method AFTER printing message of queue");
			System.out.println("Now Trying to Read Message Text Content");
			System.out.println(((TextMessage)message).getText());
			System.out.println("Kanav - After Reading message text content");
		} 
    	catch (Exception e) 
    	{
			e.printStackTrace();
		}
        
    }

}
