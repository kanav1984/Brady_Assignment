package com.bradytechnologies.assignments.java.ejb.stateless.service;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;

/**
 * Session Bean implementation class PetDetailsService
 */
@Stateless(mappedName = "PetDetailsService")
@LocalBean
public class PetDetailsService implements PetDetailsServiceRemote {

    public PetDetailsService() {
    	
    }

	@Override
	public String[] getPetDetails() {
		String[] petnames = {"Pet1", "Pet2","Pet3", "HorseName1", "HorseName2", "CatName1", "CatName2", "Dogname1", "DogName2"};
		return petnames;
	}

}
