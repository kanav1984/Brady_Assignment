package com.bradytechnologies.assignments.java.clientgui.swing;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class ParentWindow {

	private static JFrame parentWindowFrame;
	private static JLabel parentWindowContentPanelLabel1_intro=null;
	private static JLabel parentWindowContentPanelLabel2_name=null;
	private static JButton parentWindowContentPanelButton1 =null;
//	private static ActionListener parentWindowContentPanelButton1ActionListener =null;
	
	
	/**
	 * Create the GUI and show it. For thread safety, this method should be invoked
	 * from the event-dispatching thread.
	 */
	public static void createAndShowParentWindow() {
		
		JComponent parentWindowContentPanel = createParentWindowContentPanel();
		parentWindowContentPanel.setOpaque(true); // content panes must be opaque
		// Create and set up the window.
		parentWindowFrame = new JFrame("Name That Baby");
		parentWindowFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		parentWindowFrame.setContentPane(parentWindowContentPanel);
		parentWindowFrame.pack();
		parentWindowFrame.setVisible(true);
		
		parentWindowContentPanelButton1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				String selectedName = ParentWindowChild1Window.createAndShowChild1Window1(parentWindowFrame, parentWindowContentPanelButton1, "Baby names ending in O:","Name Chooser", parentWindowContentPanelLabel2_name.getText(), "Cosmo  ");

				parentWindowContentPanelLabel2_name.setText(selectedName);
			}
		});
	}
	
		
	private static JPanel createParentWindowContentPanel() {
		parentWindowContentPanelLabel1_intro = new JLabel("The chosen name:");
		parentWindowContentPanelLabel2_name = new JLabel("Please click below to select petName");
		//name.setFont(getAFont());
		//final JButton button = new JButton("Pick a new name...");
		parentWindowContentPanelButton1 = new JButton("Pick a new name...");

		// Create the panel we'll return and set up the layout.
		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.PAGE_AXIS));
		panel.setBorder(BorderFactory.createEmptyBorder(200, 200, 100, 200));
		parentWindowContentPanelLabel1_intro.setAlignmentX(JComponent.CENTER_ALIGNMENT);
		parentWindowContentPanelLabel2_name.setAlignmentX(JComponent.CENTER_ALIGNMENT);
		parentWindowContentPanelButton1.setAlignmentX(JComponent.CENTER_ALIGNMENT);

		// Add the labels to the content pane.
		panel.add(parentWindowContentPanelLabel1_intro);
		panel.add(Box.createVerticalStrut(100)); // extra space
		panel.add(parentWindowContentPanelLabel2_name);
		panel.add(Box.createVerticalStrut(100)); // extra space
		panel.add(parentWindowContentPanelButton1);

		return panel;
	}
}
