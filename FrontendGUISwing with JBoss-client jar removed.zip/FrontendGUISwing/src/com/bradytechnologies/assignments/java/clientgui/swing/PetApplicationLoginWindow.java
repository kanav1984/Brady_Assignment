package com.bradytechnologies.assignments.java.clientgui.swing;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.File;
import java.net.URL;

public class PetApplicationLoginWindow extends JFrame {

	Container container = getContentPane();
	JLabel userLabel = new JLabel("USERNAME");
	JLabel passwordLabel = new JLabel("PASSWORD");
	JTextField userTextField = new JTextField();
	JPasswordField passwordField = new JPasswordField();
	JButton loginButton = new JButton("LOGIN");
	JButton resetButton = new JButton("RESET");
	JCheckBox showPassword = new JCheckBox("Show Password");
	static PetApplicationLoginWindow frame = null;

	/**
	 * Default constructor
	 */
	PetApplicationLoginWindow() 
	{
		setLayoutManager();
		setLocationAndSize();
		addComponentsToContainer();
	}

	public void setLayoutManager() {
		container.setLayout(null);
	}

	public void setLocationAndSize() {
		// Setting location and Size of each components using setBounds() method.
		userLabel.setBounds(50, 150, 100, 30);
		passwordLabel.setBounds(50, 220, 100, 30);
		userTextField.setBounds(150, 150, 150, 30);
		passwordField.setBounds(150, 220, 150, 30);
		showPassword.setBounds(150, 250, 150, 30);
		loginButton.setBounds(50, 300, 100, 30);
		resetButton.setBounds(200, 300, 100, 30);

	}

	public void addComponentsToContainer() {
		// Adding each components to the Container
		container.add(userLabel);
		container.add(passwordLabel);
		container.add(userTextField);
		container.add(passwordField);
		container.add(showPassword);
		container.add(loginButton);
		container.add(resetButton);
		
		/**
		 * add action to login button
		 */
		loginButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				System.out.println("Login Button clicked");
				if("admin".equalsIgnoreCase(userTextField.getText()) && "admin".equalsIgnoreCase(passwordField.getText()))
				{
					ParentWindow.createAndShowParentWindow();
					frame.setVisible(false);
				}
			}
		});
		
		/**
		 * Add action to reset button
		 */
		resetButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				System.out.println("RESET Button clicked");
				userTextField.setText("");
				passwordField.setText("");
			}
		});
	}
	
	
	public static void main(String[] a)
	{
		frame = new PetApplicationLoginWindow();
		frame.setTitle("Login Form");
		frame.setVisible(true);
		frame.setBounds(10, 10, 370, 600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
		
		try {
		String classpath = System.getProperty("java.class.path");
		System.out.println("Kanav - Login Window classpath is " + classpath);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		try 
		{
			final File f = new File(PetApplicationLoginWindow.class.getProtectionDomain().getCodeSource().getLocation().getPath());
			System.out.println("\n\n Kanav - Classpath entry for file is : " + f);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}

	}

}
