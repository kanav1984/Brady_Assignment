package com.bradytechnologies.assignments.java.backend.services.web.servlet;

import java.io.IOException;
import java.util.Arrays;

import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bradytechnologies.assignments.java.ejb.stateless.service.PetDetailsServiceRemote;

/**
 * Servlet implementation class EJBCommunicator
 */
@WebServlet("/EJBCommunicator")
public class EJBCommunicator extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public EJBCommunicator() 
    {
    	System.out.println("EJBCommunicator Servlet constructor called");
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		System.out.println("Kanav inside Webservlet doGet() method, syso() before response.getwriter()");
		System.out.println(request.getContextPath());
		response.getWriter().append("Kanav Inside WebServlet doGet() method Served at: ").append(request.getContextPath());
		System.out.println("Kanav inside Webservlet doGet() method, syso() after response.getWriter()");
		
		try 
		{
			String jndiLookUpString ="java:global/BackendServicesEAR/EJBServices/PetDetailsService!com.bradytechnologies.assignments.java.ejb.stateless.service.PetDetailsServiceRemote"; 
			InitialContext initCntxt = new InitialContext();
			PetDetailsServiceRemote rem = (PetDetailsServiceRemote)initCntxt.lookup(jndiLookUpString);
			System.out.println("Pet Details after EJB lookup from Servlet are :");
			System.out.println(rem.getPetDetails());
			System.out.println(Arrays.toString(rem.getPetDetails()));
			response.getWriter().append("\n"+ Arrays.toString(rem.getPetDetails()));
			response.getWriter().println("...."+ Arrays.toString(rem.getPetDetails()));
		}
		catch(Exception ex)
		{
			ex.getMessage();
			ex.printStackTrace();
		}
		
	}

}
