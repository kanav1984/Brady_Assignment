package com.test;

import org.junit.Assert;
import org.junit.Test;

public class JunitTesting {

	public static void main(String[] args) 
	{
	}
	
	@Test
	public void test() {
		Assert.assertEquals("Hello Maven", new String("Hello Maven"));
	}


}
