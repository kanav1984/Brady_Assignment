package com.bradytechnologies.assignments.java.maven.hibernate.entity;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "OwnerClass")
public class OwnerClass {
	
	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ownerId")
	private int ownerId;
	
	@Column(name = "ownerName")
	private String ownerName;
	
	@Column(name = "telephoneNumber")
	private String telephoneNumber;
	
	@OneToMany(mappedBy = "ownerClass", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private Set<PetClass> petSet = new HashSet<>();

	public int getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(int ownerId) {
		this.ownerId = ownerId;
	}

	public String getOwnerName() {
		return ownerName;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	public String getTelephoneNumber() {
		return telephoneNumber;
	}

	public void setTelephoneNumber(String telephoneNumber) {
		this.telephoneNumber = telephoneNumber;
	}

	public Set<PetClass> getPetSet() {
		return petSet;
	}

	public void setPetSet(Set<PetClass> petSet) {
		this.petSet = petSet;
	}

	public OwnerClass(int ownerId, String ownerName, String telephoneNumber, Set<PetClass> petSet) {
		super();
		this.ownerId = ownerId;
		this.ownerName = ownerName;
		this.telephoneNumber = telephoneNumber;
		this.petSet = petSet;
	}

	public OwnerClass() {}

	@Override
	public int hashCode() {
		return Objects.hash(ownerId, ownerName, petSet, telephoneNumber);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OwnerClass other = (OwnerClass) obj;
		return ownerId == other.ownerId && Objects.equals(ownerName, other.ownerName)
				&& Objects.equals(petSet, other.petSet) && Objects.equals(telephoneNumber, other.telephoneNumber);
	}

	@Override
	public String toString() {
		return "OwnerClass [ownerId=" + ownerId + ", ownerName=" + ownerName + ", telephoneNumber=" + telephoneNumber
				+ ", petSet=" + petSet + "]";
	}
	
	
	
}
