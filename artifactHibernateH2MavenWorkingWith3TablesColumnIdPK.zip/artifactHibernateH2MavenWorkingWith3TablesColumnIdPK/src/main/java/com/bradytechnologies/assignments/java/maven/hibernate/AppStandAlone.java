package com.bradytechnologies.assignments.java.maven.hibernate;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.bradytechnologies.assignments.java.maven.hibernate.entity.OwnerClass;
import com.bradytechnologies.assignments.java.maven.hibernate.entity.PetClass;
import com.bradytechnologies.assignments.java.maven.hibernate.entity.VaccineClass;
import com.bradytechnologies.assignments.java.maven.hibernate.util.HibernateUtil;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.JoinType;
import jakarta.persistence.criteria.Root;

public class AppStandAlone {

	public static void main(String[] args) {

		OwnerClass owner1 = new OwnerClass(30, "owner1Name", "telephoneNo1", null);
		OwnerClass owner2 = new OwnerClass(31, "owner2Name", "telephoneNo1", null);
		PetClass pet1 = new PetClass(10, "PetName1", 10, owner1, null);
		PetClass pet2 = new PetClass(11, "PetName2", 10, owner1, null);
		PetClass pet3 = new PetClass(12, "PetName3", 10, owner2, null);
		PetClass pet4 = new PetClass(13, "PetName4", 10, owner1, null);
		PetClass pet5 = new PetClass(14, "PetName5", 10, owner2, null);
		PetClass pet6 = new PetClass(15, "PetName6", 10, owner1, null);
		VaccineClass vaccine1 = new VaccineClass(1, "timeOfVaccine1", pet1);
		VaccineClass vaccine2 = new VaccineClass(2, "timeOfVaccine2", pet4);
		VaccineClass vaccine3 = new VaccineClass(3, "timeOfVaccine3", pet2);
		VaccineClass vaccine4 = new VaccineClass(4, "timeOfVaccine4", pet2);
		VaccineClass vaccine5 = new VaccineClass(5, "timeOfVaccine5", pet3);
		VaccineClass vaccine6 = new VaccineClass(6, "timeOfVaccine6", pet1);
		VaccineClass vaccine7 = new VaccineClass(7, "timeOfVaccine6", pet1);
		
		
		//pet1.setVaccineSet(vaccineSet1);

		Transaction transaction = null;
		Session session = null;

		try {
			session = HibernateUtil.getSessionFactory().openSession();
			transaction = session.beginTransaction();

			session.save(owner1);
			session.save(owner2);
			session.save(pet1);
			session.save(pet2);
			session.save(pet3);
			session.save(pet4);
			session.save(pet5);
			session.save(pet6);
			session.save(vaccine1);
			session.save(vaccine2);
			session.save(vaccine3);
			session.save(vaccine4);
			session.save(vaccine5);
			session.save(vaccine6);
			session.save(vaccine7);
			

			/*
			 * String hql =
			 * "FROM PetClass p JOIN FETCH p.ownerClass o WHERE o.petName = :petNameParam";
			 * Query<PetClass> petClassQuery = session.createQuery(hql, PetClass.class);
			 * petClassQuery.setParameter("petNameParam", "PetName1"); List<PetClass>
			 * petClassList = petClassQuery.getResultList();
			 * 
			 * for(PetClass pet : petClassList ) {
			 * System.out.println("Pet Details after joining table is " + pet.toString()); }
			 */

			//CriteriaBuilder builder = session.getCriteriaBuilder();
			//CriteriaQuery<PetClass> criteria = builder.createQuery(PetClass.class);
			//Root<PetClass> petRoot = criteria.from(PetClass.class);
			//Join<Object, Object> ownerJoin = petRoot.join("ownerClass", JoinType.INNER);
			//Join<Object, Object> vaccineSetJoin = petRoot.join("vaccineSet", JoinType.RIGHT);
			//Join<Object, Object> vaccineClassJoin = petRoot.join("vaccineClass", JoinType.LEFT);

			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<VaccineClass> criteria = builder.createQuery(VaccineClass.class);
			Root<VaccineClass> vaccineRoot = criteria.from(VaccineClass.class);
			Join<Object, Object> petJoin = vaccineRoot.join("petClass", JoinType.INNER);
			
			/*
			below commented query in this block works but is not understandable
			criteria.select(petRoot).where(builder.equal(ownerJoin.get("ownerId"), new Integer(30)));
			 */
			
			criteria.where(builder.equal(petJoin.get("petId"), 10));
			//criteria.where(builder.equal(vaccineRoot.get("vaccineId"), 1));
			/*not working*/			//criteria.where(builder.equal(petJoin.get("vaccineId"), 1));
	
			//Date date = new Date();
			//System.out.println(date);
			
			List<VaccineClass> vaccineList = session.createQuery(criteria).getResultList();
			System.out.println("vaccineList size is " + vaccineList.size());

			for (VaccineClass vaccine : vaccineList) {
				System.out.println("Vaccine associated From Query Criterion -> " + vaccine.toString());
			}
			
			/*
			Below commented Code is to print table data from H2 database
			 
			 
			String jdbcURL = "jdbc:h2:mem:test";
			String username = "sa";
			String password ="";
			PreparedStatement ps = null;
			Connection conn =null;
			ResultSet rs = null;
			
			try 
			{
				conn = DriverManager.getConnection(jdbcURL, username, password);
				ps = conn.prepareStatement("select * from PetClass");
				rs = ps.executeQuery();
				System.out.println("ResultSet is " + rs);
				
				while(rs.next())
				{
					System.out.println(rs.getString(1));
				}
			}
			catch(Exception ex)
			{
				System.out.println("Kanav - Exception occured while viewing table data in DB");
				ex.printStackTrace();
			}
			finally 
			{
				ps.close();
				rs.close();
				conn.close();
			}
			*/
			
		} 
		catch (Exception ex) 
		{
			ex.printStackTrace();
		} 
		finally 
		{
			session.close();
		}

	}

}
