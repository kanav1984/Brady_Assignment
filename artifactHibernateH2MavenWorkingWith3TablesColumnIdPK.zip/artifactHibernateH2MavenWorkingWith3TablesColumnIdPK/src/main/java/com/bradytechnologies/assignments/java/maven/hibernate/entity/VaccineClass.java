package com.bradytechnologies.assignments.java.maven.hibernate.entity;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "VaccineClass")
public class VaccineClass {
	
	
	@Id
   // @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="vaccineId")
    private int vaccineId;
	
	@Column(name="timeOfVaccination")
    private String timeOfVaccination;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "petId")
	private PetClass petClass;

	public int getVaccineId() {
		return vaccineId;
	}

	public void setVaccineId(int vaccineId) {
		this.vaccineId = vaccineId;
	}

	public String getTimeOfVaccination() {
		return timeOfVaccination;
	}

	public void setTimeOfVaccination(String timeOfVaccination) {
		this.timeOfVaccination = timeOfVaccination;
	}

	public PetClass getPetClass() {
		return petClass;
	}

	public void setPetClass(PetClass petClass) {
		this.petClass = petClass;
	}

	public VaccineClass(int vaccineId, String timeOfVaccination, PetClass petClass) {
		super();
		this.vaccineId = vaccineId;
		this.timeOfVaccination = timeOfVaccination;
		this.petClass = petClass;
	}

	public VaccineClass() {}

	@Override
	public int hashCode() {
		return Objects.hash(petClass, timeOfVaccination, vaccineId);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		VaccineClass other = (VaccineClass) obj;
		return Objects.equals(petClass, other.petClass) && Objects.equals(timeOfVaccination, other.timeOfVaccination)
				&& vaccineId == other.vaccineId;
	}

	@Override
	public String toString() {
		return "VaccineClass [vaccineId=" + vaccineId + ", timeOfVaccination=" + timeOfVaccination + ", petClass="
				+ petClass + "]";
	}
}
