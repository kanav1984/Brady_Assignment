package com.bradytechnologies.assignments.java.maven.hibernate.entity;

import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "PetClass")
public class PetClass {
	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "petId")
	private int petId;
	
	@Column(name="petName")
	private String petName;
	
	@Column(name="petAge")
	private int petAge;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ownerId")
	private OwnerClass ownerClass;
	
	@OneToMany(mappedBy = "petClass", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private Set<VaccineClass> vaccineSet = new HashSet<>();


	public int getPetId() {
		return petId;
	}

	public void setPetId(int petId) {
		this.petId = petId;
	}

	public String getPetName() {
		return petName;
	}

	public void setPetName(String petName) {
		this.petName = petName;
	}


	public int getPetAge() {
		return petAge;
	}

	public void setPetAge(int petAge) {
		this.petAge = petAge;
	}

	public OwnerClass getOwnerClass() {
		return ownerClass;
	}

	public void setOwnerClass(OwnerClass ownerClass) {
		this.ownerClass = ownerClass;
	}

	public Set<VaccineClass> getVaccineSet() {
		return vaccineSet;
	}

	public void setVaccineSet(Set<VaccineClass> vaccineSet) {
		this.vaccineSet = vaccineSet;
	}


	public PetClass(int petId, String petName, int petAge, OwnerClass ownerClass, Set<VaccineClass> vaccineSet) {
		super();
		this.petId = petId;
		this.petName = petName;
		this.petAge = petAge;
		this.ownerClass = ownerClass;
		this.vaccineSet = vaccineSet;
	}
	
	public PetClass() {}


	@Override
	public int hashCode() {
		return Objects.hash(ownerClass, petAge, petId, petName, vaccineSet);
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PetClass other = (PetClass) obj;
		return Objects.equals(ownerClass, other.ownerClass) && petAge == other.petAge && petId == other.petId
				&& Objects.equals(petName, other.petName) && Objects.equals(vaccineSet, other.vaccineSet);
	}


	@Override
	public String toString() {
		return "PetClass [petId=" + petId + ", petName=" + petName + ", petAge=" + petAge + ", ownerClass=" + ownerClass
				+ ", vaccineSet=" + vaccineSet + "]";
	}
	
}
